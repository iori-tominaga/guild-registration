# Handoff: ドラゴンクエスト風 冒険者ギルドアプリ

## Overview
冒険者ギルドWebアプリのDQ（ドラクエ）風UIリデザイン。プレイヤー登録 → ギルド本部 → モンスターとのターン制バトル、という冒険者ライフを擬似体験するアプリ。レトロゲーム感（ピクセルフォント、ドット絵、8bit効果音、青枠ウィンドウ）を最優先したビジュアル。

含まれる画面：
1. **冒険者登録** (`Guild Registration.html`) — 名前・職業・自己紹介の入力ウィザード
2. **バトル画面** (`battle.html`) — モンスターとのターン制戦闘
3. **アイコンセット** (`Icon Set Preview.html` + `icons.js`) — 39種のドット絵SVG（キャラ/装備/属性/モンスター）
4. **キャラクターパーツ** (`Character Parts Preview.html` + `parts.js`) — ミックス＆マッチ可能な人物パーツ（頭・胴・腕・脚）

## About the Design Files
このバンドルに含まれるファイルは **HTMLで作成されたデザインリファレンス（プロトタイプ）** です。プロダクションコードとしてそのまま使うものではなく、最終的な見た目とインタラクションを示すためのモックです。

対象コードベース（React/Vue/Next.js等）の既存環境・パターン・ライブラリに合わせて **再実装** してください。もしまだ環境が決まっていない場合は、プロジェクトに最適なフレームワークを選定して実装してください。なお、現プロトタイプは React 18 (CDN) + Babel Standalone で書かれており、ビルドツールなしで動作します。

## Fidelity
**High-fidelity (hifi)**：色・タイポグラフィ・余白・インタラクション・効果音まで実装済みのピクセルパーフェクトなモックです。実装時はデザイントークン（後述）を正確に再現してください。

## Screens / Views

### 1. Guild Registration（冒険者登録）
- **Purpose**: 新規プレイヤーが名前・職業・自己紹介を登録してギルドカードを発行する
- **Layout**: 中央寄せ縦並び。星空背景の上に DQ風ウィンドウを配置。
  - タイトル「冒険者ギルド」(16px, #ffec40)
  - 進捗ドット (5ステップ)
  - メインウィンドウ (max-width: 600px)
- **Steps**:
  - Step 0 なまえ: テキスト入力 (最大10文字) + 「けってい」ボタン
  - Step 1 しょくぎょう: 9職業リスト＋カーソル↑↓選択＋右側にスプライト＆ステータスバープレビュー
  - Step 2 じこしょうかい: textarea (最大200文字)
  - Step 3 かくにん: 入力内容カード + 「はい/いいえ」
  - Step 4 かんりょう: フラッシュ演出 + ギルドカード発行（ID/Lv1/ランク）
- **Components**:
  - `.dq-window` (詳細は Design Tokens 参照)
  - `.dq-input` / `.dq-textarea`：背景 #000030、3pxグレー枠、フォーカス時 #ffec40
  - `.dq-btn`：青背景＋3pxグレー枠＋3pxドロップシャドウ。hover時 #ffec40。active時 translate(2px,2px)
  - クラスSpriteは SVG (12×16 viewBox, image-rendering:pixelated)

### 2. Battle Screen（バトル画面）
- **Purpose**: プレイヤー vs モンスター 1対1ターン制バトル
- **Layout**: max-width 520px縦並び。モバイル縦持ち1画面に収まる。
  - フィールド (180px高、グラデ背景 + 地面パターン)
  - プレイヤーステータス (HP/MP バー)
  - TURN表示
  - コマンドウィンドウ (2×2グリッド or 呪文リスト)
  - 戦闘ログ (最新3行、84px高)
- **Components**:
  - **モンスター表示**: emoji 64px + idleアニメ (2s上下) / hitアニメ (シェイク+ヒュー回転) / dyingアニメ (フェード+縮小)
  - **HPバー**: 緑グラデ、25%未満で赤＋pulse、50%未満で黄色
  - **MPバー**: 青グラデ #80c0ff → #40b0ff → #2070c0
  - **コマンド**: こうげき/まほう/ぼうぎょ/にげる の4種、▶カーソル
  - **呪文リスト**: メラ/ヒャド/ギラ/ホイミ/ベホイミ（MPコスト表示、MP不足は disabled）
  - **ログ**: `▸` プレフィックス、種別で色分け（dmg=赤/heal=緑/magic=青/system=黄）
- **Result Overlay**:
  - 勝利「しょうり！」 #ffec40, 22px, letter-spacing 6px, resultPop アニメ
  - 敗北「やられてしまった…」 #ff8080
  - 報酬リスト（XP/Gold）
  - レベルアップ時は専用バナー（border-top/bottom #ffd700 + glow animation）

### 3. Icon Set Preview
- 39個のドット絵SVG（characters 9 / equipment 14 / elements 6 / monsters 10）
- 各SVGは `shape-rendering="crispEdges"` + `image-rendering:pixelated` でドット感維持
- ▼JSONボタンで `dq-icons.json` をダウンロード可能

### 4. Character Parts Preview
- ミックス＆マッチ可能な5パートシステム（heads 9 / bodies 4 / rightArms 6 / leftArms 4 / legs 9）
- 各パートは `<rect>` 文字列のみ。12×16グリッドの指定ゾーン内で描画
- ビルダーUIで自由に組み合わせ可能

## Interactions & Behavior

### キーボード操作（全画面共通）
- `↑↓←→`：カーソル移動 (cursor sfx)
- `Enter` / `Space`：決定 (select sfx)
- `Esc`：戻る (cancel sfx)

### Battle 戦闘フロー
1. プレイヤーコマンド選択 → 行動アニメ → ダメージ計算 → ログ追加
2. モンスターHPが0 → `monsterDefeated()` → 勝利演出 → Result
3. プレイヤー行動後 → `monsterTurn()` で敵反撃 → HP更新
4. プレイヤーHPが0 → `playerDefeated()` → 敗北Result
5. 「にげる」成功率50%、ボスは逃走不可

### アニメーション
- `monsterIdle`: 2s ease-in-out infinite (translateY 0→-3)
- `monsterHit`: 0.4s (translateX shake + brightness + hue-rotate)
- `monsterDeath`: 0.8s (opacity 1→0, scale 1→0.5, translateY +40, blur)
- `dmgFloat`: 0.9s (translateY 0→-60, scale 0.6→1.2→1, opacity 0→1→0)
- `resultPop`: 0.5s (scale 0.3→1.15→1)
- `levelGlow`: 1.2s alternate (text-shadow glow)
- `shake` (screen): 0.3s 4方向ランダム
- `screenFlash`: 0.25s 全画面オーバーレイ (40%地点で opacity 0.8)

### Audio (Web Audio API)
全効果音を OscillatorNode で合成（外部ファイル不要）：
- cursor: 800Hz square 0.04s
- select: 1000Hz + 1400Hz square
- attack: 200Hz→140Hz sawtooth
- hit: 80Hz sawtooth + 120Hz square
- magic: 400/600/800/1200Hz triangle 連鎖
- heal: 600/800/1000/1200Hz sine 連鎖
- victory: 523/659/784/1047/1319Hz square
- defeat: 400→100Hz sawtooth 下降
- levelUp: C5→E5→G5→C6→G5→C6→E6 square

## State Management

### Registration
```ts
{ step: 0|1|2|3|4, name: string, cls: ClassObj|null, profile: string }
```

### Battle
```ts
{
  player: { name, cls, lv, hp, maxHp, mp, maxMp, atk, def, gold, xp },
  monster: { id, name, emoji, lv, hp, maxHp, atk, def, xp, gold, boss? },
  mode: 'command'|'spell'|'wait'|'result',
  cursor: number,
  hitState: 'idle'|'hit'|'dying',
  magicFx: 'fire'|'ice'|'heal'|null,
  popups: { id, text, kind, x, y }[],
  log: { id, text, kind }[],
  defending: boolean,
  result: ResultObj|null,
  turn: number
}
```

### URL Parameters
- `battle.html?monster=slime` でモンスター指定

## Design Tokens

### Colors
| Role | Hex |
|---|---|
| 背景（最暗） | `#000810` |
| ウィンドウ背景 | `#000060` |
| ウィンドウ内背景 | `#000030` |
| メインイエロー（タイトル・選択中） | `#ffec40` |
| ゴールド（強調・枠） | `#ffd700` |
| テキスト薄青 | `#c0d8ff` |
| テキスト青紫 | `#a0c0ff` |
| ボーダーグレー | `#c8c8c8` |
| インナーボーダー青 | `#4848b8` |
| HP緑 (明) | `#80ff80` |
| HP緑 | `#40ff40` |
| HP緑 (暗) | `#20c020` |
| HP低 (黄→橙) | `#ffff80` / `#ffc040` / `#ff8040` |
| HP危 (赤) | `#ffa0a0` / `#ff8080` / `#c02020` |
| MP青 (明) | `#80c0ff` |
| MP青 | `#40b0ff` |
| MP青 (暗) | `#2070c0` |

### Typography
- Font Family: `'Press Start 2P', monospace` (Google Fonts)
- Title: 16px, letter-spacing 4px, text-shadow `2px 2px #000`
- Section header: 11-12px, letter-spacing 2-3px
- Body: 10-11px, letter-spacing 1px
- Small hint: 7-9px, letter-spacing 1-2px
- Result title: 22px, letter-spacing 6px

### Spacing
- Window padding: 10-20px
- Window gap: 8px (battle), 16-20px (registration)
- Button padding: 12px 20-28px
- Min touch target: 44px (mobile)

### Window Style (`.dq-window`)
```css
background: #000060;
border: 4px solid #c8c8c8;
box-shadow:
  inset 0 0 0 2px #ffffff,
  0 0 0 2px #000,
  4px 4px 0 #000;  /* 6px for registration */
```
+ `::before` で `inset: 3px; border: 2px solid #4848b8` の内側枠

### Button Style (`.dq-btn`)
```css
background: #000060;
border: 3px solid #c8c8c8;
box-shadow: 3px 3px 0 #000;
min-height: 44px;
/* hover */ color: #ffec40; border-color: #ffec40;
/* active */ transform: translate(2px, 2px); box-shadow: 1px 1px 0 #000;
```

### Bar Style
- Track: height 8-10px, background `#000030`, border `2px solid #404080`
- Fill: linear-gradient 180deg (3-stop)
- Transition: width 0.35s ease

## Assets
- **フォント**: Google Fonts「Press Start 2P」
- **背景**: 星空は CSS radial-gradient のみで描画（画像不要）
- **キャラクター**: 自作SVG（`icons.js` / `parts.js`）
- **モンスター**: 絵文字（🟦🟥🐺👻👹💀🗿🐲🐉）— SVGスプライト化したい場合は `icons.js` の `monsters` を使用
- **効果音**: Web Audio APIで合成（外部ファイル不要）

## Files
本バンドル内ファイル：
- `Guild Registration.html` — 登録ウィザード
- `battle.html` — バトル画面
- `Icon Set Preview.html` + `icons.js` + `dq-icons.json` — アイコンカタログ
- `Character Parts Preview.html` + `parts.js` + `dq-parts.json` — キャラパーツ

## Implementation Notes
- React 18 (CDN) + Babel Standaloneで動作中。本番化時は通常のビルドツール（Vite/Next.js等）に移行推奨
- すべての効果音は Web Audio APIで合成のため、外部音声ファイルは不要
- スプライトはSVG文字列をinjection。Reactコンポーネント化する場合は `dangerouslySetInnerHTML` または個別の `<rect>` JSX化を選択
- モバイルでは `<meta viewport ... maximum-scale=1.0>` でiOSズーム抑制
- フォントサイズは入力欄で16px以上を維持してiOS自動ズームを防止
