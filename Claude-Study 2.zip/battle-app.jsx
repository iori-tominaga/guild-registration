const { useState, useEffect, useRef, useCallback, useMemo } = React;

// ─── Audio ──────────────────────────────────────────────────────
let audioCtx = null;
const A = () => (audioCtx ||= new (window.AudioContext || window.webkitAudioContext)());
function beep(freq=440, dur=0.08, type='square', vol=0.12) {
  try {
    const c = A(), o = c.createOscillator(), g = c.createGain();
    o.connect(g); g.connect(c.destination);
    o.type = type; o.frequency.setValueAtTime(freq, c.currentTime);
    g.gain.setValueAtTime(vol, c.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + dur);
    o.start(); o.stop(c.currentTime + dur);
  } catch(e) {}
}
const sfx = {
  cursor: () => beep(800, 0.04, 'square', 0.08),
  select: () => { beep(1000, 0.05); beep(1400, 0.08); },
  attack: () => { beep(200, 0.05, 'sawtooth', 0.2); setTimeout(() => beep(140, 0.1, 'sawtooth', 0.2), 30); },
  hit:    () => { beep(80, 0.1, 'sawtooth', 0.25); beep(120, 0.08, 'square', 0.15); },
  magic:  () => { [400,600,800,1200].forEach((f,i) => setTimeout(() => beep(f, 0.1, 'triangle', 0.15), i*40)); },
  heal:   () => { [600,800,1000,1200].forEach((f,i) => setTimeout(() => beep(f, 0.12, 'sine', 0.2), i*60)); },
  defend: () => beep(300, 0.15, 'triangle', 0.2),
  flee:   () => { [400,300,200,150].forEach((f,i) => setTimeout(() => beep(f, 0.08, 'square', 0.12), i*40)); },
  victory:() => [523,659,784,1047,1319].forEach((f,i) => setTimeout(() => beep(f, 0.2, 'square', 0.2), i*150)),
  defeat: () => [400,300,200,150,100].forEach((f,i) => setTimeout(() => beep(f, 0.3, 'sawtooth', 0.15), i*200)),
  levelUp:() => [523,659,784,1047,784,1047,1319].forEach((f,i) => setTimeout(() => beep(f, 0.15, 'square', 0.2), i*120)),
};

// ─── Data ───────────────────────────────────────────────────────
// monster category drives background
const MONSTERS = [
  { id:'slime',       name:'スライム',         lv:1, hp:15, atk:5,  def:2, xp:5,  gold:8,  cat:'slime' },
  { id:'red-slime',   name:'あかスライム',     lv:1, hp:20, atk:7,  def:3, xp:8,  gold:12, cat:'slime' },
  { id:'wolf',        name:'おおかみ',         lv:2, hp:28, atk:9,  def:4, xp:14, gold:18, cat:'beast' },
  { id:'orc',         name:'オーク',           lv:3, hp:45, atk:13, def:7, xp:28, gold:38, cat:'beast' },
  { id:'ghost',       name:'ゴースト',         lv:2, hp:24, atk:11, def:2, xp:16, gold:22, cat:'undead' },
  { id:'skeleton',    name:'スケルトン',       lv:3, hp:40, atk:14, def:5, xp:30, gold:40, cat:'undead' },
  { id:'golem',       name:'ゴーレム',         lv:4, hp:70, atk:16, def:12,xp:52, gold:75, cat:'humanoid' },
  { id:'dark-knight', name:'あんこくのきし',   lv:4, hp:60, atk:20, def:8, xp:58, gold:80, cat:'humanoid' },
  { id:'wyvern',      name:'ワイバーン',       lv:5, hp:90, atk:22, def:10,xp:90, gold:120,cat:'dragon' },
  { id:'dragon-lord', name:'りゅうおう',       lv:5, hp:150,atk:28, def:14,xp:200,gold:300,cat:'dragon', boss:true },
];

const BG_MAP = {
  slime:    { bg: 'bg-grass',     ground: 'grass' },
  beast:    { bg: 'bg-forest',    ground: 'dirt' },
  undead:   { bg: 'bg-graveyard', ground: 'bone' },
  humanoid: { bg: 'bg-castle',    ground: 'stone' },
  dragon:   { bg: 'bg-lava',      ground: 'lava' },
};

const SPELLS = [
  { id:'mera',   name:'メラ',     cost:3,  pow:14, type:'fire', desc:'敵1体に炎ダメージ'    },
  { id:'hyado',  name:'ヒャド',   cost:4,  pow:18, type:'ice',  desc:'敵1体に氷ダメージ'    },
  { id:'gira',   name:'ギラ',     cost:6,  pow:24, type:'fire', desc:'敵1体に大炎ダメージ'  },
  { id:'hoimi',  name:'ホイミ',   cost:3,  pow:25, type:'heal', desc:'HPを回復する'          },
  { id:'behoimi',name:'ベホイミ', cost:7,  pow:60, type:'heal', desc:'HPを大きく回復する'    },
];

// Class → parts mapping (for parts.js DQ_PARTS)
const CLASS_PARTS = {
  'せんし':       { head:'warrior',  body:'chain-armor',  rarm:'iron-sword',   larm:'iron-shield',  legs:'warrior'  },
  'まほうつかい': { head:'mage',     body:'default',      rarm:'wood-stick',   larm:'default',      legs:'mage'     },
  'そうりょ':     { head:'priest',   body:'cloth-armor',  rarm:'default',      larm:'default',      legs:'priest'   },
  'とうぞく':     { head:'thief',    body:'default',      rarm:'copper-sword', larm:'default',      legs:'thief'    },
  'しょうにん':   { head:'merchant', body:'cloth-armor',  rarm:'default',      larm:'default',      legs:'merchant' },
  'ぶとうか':     { head:'martial',  body:'default',      rarm:'default',      larm:'default',      legs:'martial'  },
  'うたうたい':   { head:'bard',     body:'cloth-armor',  rarm:'wood-stick',   larm:'default',      legs:'bard'     },
  'けんじゃ':     { head:'sage',     body:'cloth-armor',  rarm:'wood-stick',   larm:'magic-shield', legs:'sage'     },
};

// ─── Helpers ────────────────────────────────────────────────────
const rng = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const wait = (ms) => new Promise(r => setTimeout(r, ms));

// ─── Sprites ─────────────────────────────────────────────────────
function MonsterSprite({ id, state }) {
  const svg = window.DQ_ICONS?.monsters?.[id] || '';
  // upscale to 112 from base 32
  const sized = svg.replace(/width="\d+"/, 'width="112"').replace(/height="\d+"/, 'height="112"');
  return <div className={`monster-sprite ${state}`} dangerouslySetInnerHTML={{__html: sized}}/>;
}

function PlayerSprite({ cls }) {
  const P = window.DQ_PARTS;
  const m = CLASS_PARTS[cls] || CLASS_PARTS['せんし'];
  const rects =
    (P.heads[m.head] || P.heads.other) +
    (P.bodies[m.body] || P.bodies.default) +
    (P.rightArms[m.rarm] || P.rightArms.default) +
    (P.leftArms[m.larm] || P.leftArms.default) +
    (P.legs[m.legs] || P.legs.other);
  return (
    <div className="player-sprite"
      dangerouslySetInnerHTML={{__html:
        `<svg width="96" height="128" viewBox="0 0 12 16" shape-rendering="crispEdges" style="image-rendering:pixelated">${rects}</svg>`
      }}/>
  );
}

// Shield decoration (simple SVG kite shield)
function ShieldUp() {
  return (
    <svg className="shield-up" viewBox="0 0 16 22" shape-rendering="crispEdges" style={{imageRendering:'pixelated'}}>
      <rect x="3" y="1" width="10" height="2" fill="#c0c0c0"/>
      <rect x="2" y="3" width="12" height="10" fill="#a0a0a0"/>
      <rect x="3" y="13" width="10" height="2" fill="#808080"/>
      <rect x="5" y="15" width="6" height="2" fill="#808080"/>
      <rect x="6" y="17" width="4" height="2" fill="#606060"/>
      <rect x="7" y="19" width="2" height="2" fill="#606060"/>
      <rect x="6" y="5" width="4" height="6" fill="#ffd700"/>
      <rect x="2" y="3" width="2" height="1" fill="#ffffff"/>
    </svg>
  );
}

// Magic circle (rotating SVG)
function MagicCircle({ type, show }) {
  if (!show) return null;
  const color = type === 'fire' ? '#ff6020' : type === 'ice' ? '#80c0ff' : '#ffec40';
  return (
    <svg className="magic-circle show" viewBox="0 0 100 100" style={{filter:`drop-shadow(0 0 8px ${color})`}}>
      <circle cx="50" cy="50" r="46" stroke={color} strokeWidth="2" fill="none"/>
      <circle cx="50" cy="50" r="34" stroke={color} strokeWidth="1" fill="none"/>
      <polygon points="50,10 80,68 20,68" stroke={color} strokeWidth="1.5" fill="none"/>
      <polygon points="50,90 80,32 20,32" stroke={color} strokeWidth="1.5" fill="none"/>
      <text x="50" y="20" fontSize="6" fill={color} textAnchor="middle">★</text>
      <text x="50" y="86" fontSize="6" fill={color} textAnchor="middle">★</text>
      <text x="14" y="52" fontSize="6" fill={color}>★</text>
      <text x="80" y="52" fontSize="6" fill={color}>★</text>
    </svg>
  );
}

// Background pixel decoration by category
function BgDeco({ cat }) {
  const decos = {
    slime: (
      <>
        {/* clouds */}
        <div style={{position:'absolute', top:18, left:'15%', width:30, height:8, background:'#ffffff', opacity:0.7}}/>
        <div style={{position:'absolute', top:14, left:'17%', width:20, height:6, background:'#ffffff', opacity:0.8}}/>
        <div style={{position:'absolute', top:30, left:'70%', width:24, height:7, background:'#ffffff', opacity:0.6}}/>
        {/* hills */}
        <div style={{position:'absolute', bottom:36, left:'2%', width:80, height:24, background:'#3a7028', borderRadius:'50% 50% 0 0'}}/>
        <div style={{position:'absolute', bottom:36, right:'2%', width:90, height:30, background:'#2a5020', borderRadius:'50% 50% 0 0'}}/>
        {/* tree */}
        <div style={{position:'absolute', bottom:36, left:'40%', width:6, height:18, background:'#4a2810'}}/>
        <div style={{position:'absolute', bottom:48, left:'38%', width:20, height:16, background:'#206020', borderRadius:'50%'}}/>
      </>
    ),
    beast: (
      <>
        {/* trees silhouette */}
        <div style={{position:'absolute', bottom:36, left:'5%', width:24, height:60, background:'#1a2810', clipPath:'polygon(50% 0, 100% 80%, 0 80%)'}}/>
        <div style={{position:'absolute', bottom:36, left:'25%', width:30, height:80, background:'#0a1a08', clipPath:'polygon(50% 0, 100% 80%, 0 80%)'}}/>
        <div style={{position:'absolute', bottom:36, right:'10%', width:28, height:70, background:'#1a2810', clipPath:'polygon(50% 0, 100% 80%, 0 80%)'}}/>
        <div style={{position:'absolute', bottom:36, right:'30%', width:20, height:50, background:'#0a1a08', clipPath:'polygon(50% 0, 100% 80%, 0 80%)'}}/>
        {/* sun */}
        <div style={{position:'absolute', top:14, right:'15%', width:34, height:34, background:'radial-gradient(circle, #ffaa40, #ff6020 70%)', borderRadius:'50%', boxShadow:'0 0 20px #ff8040'}}/>
      </>
    ),
    undead: (
      <>
        {/* tombstones */}
        <div style={{position:'absolute', bottom:36, left:'8%', width:18, height:24, background:'#606070'}}/>
        <div style={{position:'absolute', bottom:56, left:'8%', width:18, height:4, background:'#606070', borderRadius:'50% 50% 0 0'}}/>
        <div style={{position:'absolute', bottom:36, right:'18%', width:22, height:28, background:'#505060'}}/>
        <div style={{position:'absolute', bottom:60, right:'18%', width:22, height:4, background:'#505060', borderRadius:'50% 50% 0 0'}}/>
        {/* moon */}
        <div style={{position:'absolute', top:20, right:'8%', width:30, height:30, background:'radial-gradient(circle, #ffffff, #c0c0e0 70%)', borderRadius:'50%', boxShadow:'0 0 16px #8080c0'}}/>
        {/* fog */}
        <div style={{position:'absolute', bottom:38, left:0, right:0, height:12, background:'linear-gradient(180deg, transparent, rgba(200,200,255,0.25))'}}/>
      </>
    ),
    humanoid: (
      <>
        {/* castle wall */}
        <div style={{position:'absolute', bottom:36, left:0, right:0, height:70, background:'linear-gradient(180deg, #4a4a60, #2a2a40)'}}/>
        {/* battlements */}
        {[5,18,31,44,57,70,83].map(p => (
          <div key={p} style={{position:'absolute', bottom:106, left:p+'%', width:'7%', height:10, background:'#4a4a60'}}/>
        ))}
        {/* pillars */}
        <div style={{position:'absolute', bottom:36, left:'18%', width:8, height:70, background:'#5a5a70'}}/>
        <div style={{position:'absolute', bottom:36, right:'18%', width:8, height:70, background:'#5a5a70'}}/>
        {/* torches */}
        <div style={{position:'absolute', bottom:90, left:'25%', width:4, height:4, background:'#ff8040', boxShadow:'0 0 8px #ff6020'}}/>
        <div style={{position:'absolute', bottom:90, right:'25%', width:4, height:4, background:'#ff8040', boxShadow:'0 0 8px #ff6020'}}/>
      </>
    ),
    dragon: (
      <>
        {/* cave walls */}
        <div style={{position:'absolute', top:0, left:0, width:'25%', height:'100%', background:'linear-gradient(90deg, #1a0808, transparent)'}}/>
        <div style={{position:'absolute', top:0, right:0, width:'25%', height:'100%', background:'linear-gradient(-90deg, #1a0808, transparent)'}}/>
        {/* stalactites */}
        <div style={{position:'absolute', top:0, left:'15%', width:10, height:30, background:'#2a0808', clipPath:'polygon(50% 100%, 100% 0, 0 0)'}}/>
        <div style={{position:'absolute', top:0, left:'35%', width:8, height:20, background:'#2a0808', clipPath:'polygon(50% 100%, 100% 0, 0 0)'}}/>
        <div style={{position:'absolute', top:0, right:'25%', width:12, height:35, background:'#2a0808', clipPath:'polygon(50% 100%, 100% 0, 0 0)'}}/>
        {/* lava glow */}
        <div style={{position:'absolute', bottom:30, left:0, right:0, height:18, background:'radial-gradient(ellipse, #ffaa20 0%, transparent 70%)', filter:'blur(2px)'}}/>
      </>
    ),
  };
  return <div className="bg-deco">{decos[cat] || decos.slime}</div>;
}

// ─── Bars ───────────────────────────────────────────────────────
function HpBar({ current, max, label='HP' }) {
  const pct = (current / max) * 100;
  const cls = pct < 25 ? 'hp-fill critical' : pct < 50 ? 'hp-fill low' : 'hp-fill';
  return (
    <div className="bar-row">
      <span className="lbl">{label}</span>
      <div className="stat-track"><div className={`stat-fill ${cls}`} style={{width:pct+'%'}}/></div>
      <span className="val">{current}/{max}</span>
    </div>
  );
}
function MpBar({ current, max }) {
  const pct = (current / max) * 100;
  return (
    <div className="bar-row">
      <span className="lbl">MP</span>
      <div className="stat-track"><div className="stat-fill mp-fill" style={{width:pct+'%'}}/></div>
      <span className="val">{current}/{max}</span>
    </div>
  );
}

// ─── Field ──────────────────────────────────────────────────────
function Field({ monster, player, monsterState, playerAction, magicFx, magicCircle, showShield, particles, popups, fieldRef }) {
  const bg = BG_MAP[monster.cat] || BG_MAP.slime;
  return (
    <div className={`field ${bg.bg}`} ref={fieldRef}>
      <BgDeco cat={monster.cat}/>
      <div className={`ground ${bg.ground}`}/>

      {/* monster name plate */}
      <div className="monster-name-plate">
        <div style={{flex:1, minWidth:0}}>
          <div style={{display:'flex', alignItems:'center', gap:6}}>
            <span className="lv">Lv.{monster.lv}</span>
            <span className="name">{monster.boss ? '👑' : ''}{monster.name}</span>
          </div>
          <div className="hp-mini-row">
            <div className="stat-track" style={{flex:1, height:6}}>
              <div className={`stat-fill ${monster.hp < monster.maxHp * 0.25 ? 'hp-fill critical' : 'hp-fill'}`}
                style={{width: (monster.hp/monster.maxHp)*100 + '%'}}/>
            </div>
            <span style={{fontSize:7, color:'#c0d8ff', minWidth:46, textAlign:'right'}}>
              {monster.hp}/{monster.maxHp}
            </span>
          </div>
        </div>
      </div>

      <div className="combatant monster">
        <MonsterSprite id={monster.id} state={monsterState}/>
      </div>

      <div className={`combatant player player-act-${playerAction || 'idle'}`}>
        <PlayerSprite cls={player.cls}/>
      </div>

      {magicCircle && <MagicCircle type={magicCircle} show={true}/>}
      {magicFx && <div className={`magic-fx ${magicFx}`}>
        {magicFx === 'fire' && '🔥'}
        {magicFx === 'ice'  && '❄️'}
        {magicFx === 'heal' && '✨'}
      </div>}

      {showShield && <ShieldUp/>}

      {particles.map(p => (
        <div key={p.id} className={`elem-particle ${p.type}`}
          style={{left: p.x+'px', top: p.y+'px', '--dx': p.dx+'px', '--dy': p.dy+'px'}}/>
      ))}

      {popups.map(p => (
        <div key={p.id} className={`dmg-pop ${p.kind||''}`}
          style={{left: p.x+'px', top: p.y+'px'}}>{p.text}</div>
      ))}
    </div>
  );
}

// ─── Status Strip with centered turn ───
function StatusStrip({ player, turn }) {
  return (
    <div className="dq-window">
      <div className="dq-window-inner">
        <div className="status-strip">
          <div className="stats-cell">
            <div className="player-name-line">
              {player.name}<span className="player-meta-inline">{player.cls} Lv.{player.lv}</span>
            </div>
            <HpBar current={player.hp} max={player.maxHp}/>
            <MpBar current={player.mp} max={player.maxMp}/>
          </div>
          <div className="turn-badge">
            TURN
            <span className="num">{turn}</span>
          </div>
          <div className="stats-cell" style={{textAlign:'right'}}>
            <div style={{fontSize:7, color:'var(--text-purple)', letterSpacing:2}}>GOLD</div>
            <div style={{fontSize:11, color:'var(--gold)', letterSpacing:1}}>{player.gold} G</div>
            <div style={{fontSize:7, color:'var(--text-purple)', letterSpacing:2, marginTop:3}}>XP</div>
            <div style={{fontSize:9, color:'var(--text-pale)'}}>{player.xp}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Command Window ─────────────────────────────────────────────
function CommandWindow({ mode, cursor, setCursor, onChoose, player }) {
  const cmds = ['こうげき','まほう','ぼうぎょ','にげる'];
  if (mode === 'spell') {
    return (
      <div className="dq-window"><div className="dq-window-inner">
        <div style={{fontSize:9, color:'#a0c0ff', marginBottom:6, letterSpacing:2}}>じゅもん</div>
        <div className="spell-list">
          {SPELLS.map((s, i) => {
            const insufficient = player.mp < s.cost;
            return (
              <button key={s.id}
                className={`spell-item${cursor===i?' active':''}`}
                disabled={insufficient}
                onMouseEnter={() => setCursor(i)}
                onClick={() => onChoose(i)}>
                <span className="arrow">▶</span>
                <span>{s.name}</span>
                <span className="cost">MP {s.cost}</span>
              </button>
            );
          })}
        </div>
        <button className="spell-back" onClick={() => onChoose(-1)}>◀ もどる</button>
      </div></div>
    );
  }
  return (
    <div className="dq-window"><div className="dq-window-inner">
      <div style={{fontSize:9, color:'#a0c0ff', marginBottom:6, letterSpacing:2}}>コマンド</div>
      <div className="cmd-grid">
        {cmds.map((c, i) => (
          <button key={c}
            className={`cmd-item${cursor===i?' active':''}`}
            onMouseEnter={() => setCursor(i)}
            onClick={() => onChoose(i)}>
            <span className="arrow">▶</span>{c}
          </button>
        ))}
      </div>
    </div></div>
  );
}

// ─── Log Window (4 lines) ──────────────────────────────────────
function LogWindow({ lines }) {
  return (
    <div className="dq-window log-window"><div className="dq-window-inner">
      <div className="log-text">
        {lines.slice(-4).map(l => (
          <div key={l.id} className={`ln-${l.kind || 'normal'}`}>▸ {l.text}</div>
        ))}
      </div>
    </div></div>
  );
}

// ─── Result Overlay ─────────────────────────────────────────────
function ResultOverlay({ result, onBack }) {
  return (
    <div className="overlay">
      <div className="result-card">
        <div className="dq-window"><div className="dq-window-inner">
          <div className={`result-title ${result.type}`}>
            {result.type === 'victory' ? 'しょうり！' :
             result.type === 'flee'    ? 'にげきった！' :
             'やられてしまった…'}
          </div>
          <div style={{padding:'0 4px'}}>
            {result.type === 'victory' && <>
              <div className="reward-row"><span>たおした</span><span className="val">{result.monster.name}</span></div>
              <div className="reward-row"><span>けいけんち</span><span className="val">+ {result.xp}</span></div>
              <div className="reward-row"><span>ゴールド</span><span className="val">+ {result.gold} G</span></div>
              {result.levelUp && <div className="level-up">★ レベルアップ ★</div>}
            </>}
            {result.type === 'flee' && (
              <div className="reward-row">
                <span>ぶじ にげのびた…</span>
                <span className="val">{result.monster.name}から</span>
              </div>
            )}
            {result.type === 'defeat' && <>
              <div className="reward-row"><span>やぶれたあいて</span><span className="val">{result.monster.name}</span></div>
              <div className="reward-row"><span>うしなったG</span><span className="val" style={{color:'var(--red)'}}>- {result.lostGold}</span></div>
            </>}
          </div>
          <div style={{textAlign:'center', marginTop:16, paddingBottom:4}}>
            <button className="dq-btn" onClick={onBack} style={{color:'var(--yellow)', borderColor:'var(--yellow)'}}>
              ▶ ギルドにもどる
            </button>
          </div>
        </div></div>
      </div>
    </div>
  );
}

// ─── Main App ───────────────────────────────────────────────────
function App() {
  const initialMonster = useMemo(() => {
    const q = new URLSearchParams(location.search);
    const id = q.get('monster');
    const m = MONSTERS.find(x => x.id === id) || MONSTERS[2];
    return { ...m, maxHp: m.hp };
  }, []);

  const [player, setPlayer] = useState({
    name:'リオン', cls:'せんし', lv:4,
    hp:78, maxHp:90, mp:18, maxMp:30,
    atk:18, def:10, gold:240, xp:0,
  });
  const [monster, setMonster] = useState(initialMonster);
  const [mode, setMode] = useState('command'); // command | spell | wait | result
  const [cursor, setCursor] = useState(0);
  const [monsterState, setMonsterState] = useState('idle');
  const [playerAction, setPlayerAction] = useState('idle');
  const [magicFx, setMagicFx] = useState(null);
  const [magicCircle, setMagicCircle] = useState(null);
  const [showShield, setShowShield] = useState(false);
  const [particles, setParticles] = useState([]);
  const [popups, setPopups] = useState([]);
  const [log, setLog] = useState([
    { id: 0, text: `${initialMonster.name}が あらわれた！`, kind: 'system' }
  ]);
  const [defending, setDefending] = useState(false);
  const [result, setResult] = useState(null);
  const [shake, setShake] = useState(false);
  const [flash, setFlash] = useState(null);
  const [turn, setTurn] = useState(1);
  const fieldRef = useRef(null);
  const popupId = useRef(1);
  const logId = useRef(1);
  const particleId = useRef(1);

  const addLog = useCallback((text, kind='normal') => {
    setLog(prev => [...prev, { id: logId.current++, text, kind }]);
  }, []);

  const spawnPopup = (text, side='monster', kind='') => {
    if (!fieldRef.current) return;
    const rect = fieldRef.current.getBoundingClientRect();
    const x = (side === 'monster' ? rect.width * 0.24 : rect.width * 0.74) + rng(-20, 20);
    const y = rect.height * 0.35 + rng(-10, 10);
    const id = popupId.current++;
    setPopups(prev => [...prev, { id, text, kind, x, y }]);
    setTimeout(() => setPopups(prev => prev.filter(p => p.id !== id)), 900);
  };

  const spawnParticles = (type, side='monster', count=12) => {
    if (!fieldRef.current) return;
    const rect = fieldRef.current.getBoundingClientRect();
    const cx = (side === 'monster' ? rect.width * 0.24 : rect.width * 0.74);
    const cy = rect.height * 0.5;
    const ps = [];
    for (let i = 0; i < count; i++) {
      const ang = (Math.PI * 2 * i) / count + Math.random() * 0.3;
      ps.push({
        id: particleId.current++,
        type, x: cx, y: cy,
        dx: Math.cos(ang) * (40 + Math.random()*30),
        dy: Math.sin(ang) * (40 + Math.random()*30),
      });
    }
    setParticles(prev => [...prev, ...ps]);
    setTimeout(() => {
      setParticles(prev => prev.filter(p => !ps.find(x => x.id === p.id)));
    }, 900);
  };

  const doFlash = (color='rgba(255,255,255,0.7)') => {
    setFlash(color);
    setTimeout(() => setFlash(null), 250);
  };
  const doShake = () => { setShake(true); setTimeout(() => setShake(false), 300); };

  // ─── Actions ───
  const playerAttack = async () => {
    setMode('wait');
    setPlayerAction('attack');
    addLog(`${player.name}のこうげき！`);
    sfx.attack();
    await wait(450);
    const dmg = Math.max(1, player.atk - monster.def + rng(-3, 3));
    const crit = Math.random() < 0.1;
    const finalDmg = crit ? Math.floor(dmg * 1.6) : dmg;
    sfx.hit();
    setMonsterState('hit');
    doFlash('rgba(255,255,255,0.5)');
    spawnPopup(finalDmg, 'monster', crit ? 'crit' : '');
    addLog(`${monster.name}に ${finalDmg} のダメージ！${crit ? ' かいしんのいちげき！' : ''}`, 'dmg');
    const newHp = clamp(monster.hp - finalDmg, 0, monster.maxHp);
    setMonster(m => ({...m, hp: newHp}));
    await wait(400);
    setMonsterState('idle');
    setPlayerAction('idle');
    await wait(150);
    if (newHp <= 0) await monsterDefeated();
    else { await wait(300); monsterTurn(); }
  };

  const playerSpell = async (spellIdx) => {
    const s = SPELLS[spellIdx];
    if (player.mp < s.cost) return;
    setMode('wait');
    setPlayerAction('magic');
    setPlayer(p => ({...p, mp: p.mp - s.cost}));
    addLog(`${player.name}は ${s.name} をとなえた！`, 'magic');
    sfx.magic();
    setMagicCircle(s.type);
    spawnParticles(s.type === 'fire' ? 'fire' : s.type === 'ice' ? 'ice' : 'bolt', 'player', 14);
    await wait(700);
    setMagicCircle(null);

    if (s.type === 'heal') {
      const healed = s.pow + rng(-3, 3);
      sfx.heal();
      setMagicFx('heal');
      setPlayer(p => ({...p, hp: clamp(p.hp + healed, 0, p.maxHp)}));
      spawnPopup('+' + healed, 'player', 'heal');
      addLog(`HPが ${healed} かいふくした！`, 'heal');
      await wait(500);
      setMagicFx(null);
      setPlayerAction('idle');
      await wait(150);
      monsterTurn();
    } else {
      const dmg = Math.max(1, s.pow + rng(-3, 3));
      sfx.hit();
      doShake();
      doFlash(s.type === 'fire' ? 'rgba(255,80,40,0.5)' : 'rgba(120,200,255,0.5)');
      setMonsterState('hit');
      setMagicFx(s.type);
      spawnParticles(s.type === 'fire' ? 'fire' : 'ice', 'monster', 16);
      spawnPopup(dmg, 'monster', 'crit');
      addLog(`${monster.name}に ${dmg} のダメージ！`, 'dmg');
      const newHp = clamp(monster.hp - dmg, 0, monster.maxHp);
      setMonster(m => ({...m, hp: newHp}));
      await wait(600);
      setMagicFx(null);
      setMonsterState('idle');
      setPlayerAction('idle');
      await wait(150);
      if (newHp <= 0) await monsterDefeated();
      else { await wait(200); monsterTurn(); }
    }
  };

  const playerDefend = async () => {
    setMode('wait');
    setPlayerAction('defend');
    setShowShield(true);
    sfx.defend();
    addLog(`${player.name}は みをまもっている！`, 'system');
    setDefending(true);
    await wait(700);
    monsterTurn();
  };

  const playerFlee = async () => {
    setMode('wait');
    setPlayerAction('flee');
    sfx.flee();
    addLog(`${player.name}は にげだした！`);
    await wait(600);
    if (Math.random() < 0.5 && !monster.boss) {
      addLog('うまく にげきれた！', 'system');
      await wait(500);
      setResult({ type:'flee', monster });
      setMode('result');
    } else {
      addLog(monster.boss ? 'ボスからは にげられない！' : 'しかし まわりこまれてしまった！', 'system');
      setPlayerAction('idle');
      await wait(500);
      monsterTurn();
    }
  };

  const monsterTurn = async () => {
    await wait(250);
    addLog(`${monster.name}のこうげき！`);
    sfx.attack();
    setMonsterState('attacking');
    await wait(450);
    let dmg = Math.max(1, monster.atk - player.def + rng(-2, 2));
    if (defending) dmg = Math.floor(dmg / 2);
    sfx.hit();
    if (!defending) setPlayerAction('hit');
    doShake();
    doFlash('rgba(255,40,40,0.5)');
    spawnPopup(dmg, 'player');
    addLog(`${player.name}は ${dmg} ダメージをうけた！${defending ? ' (ぼうぎょで半減)' : ''}`, 'dmg');
    const newHp = clamp(player.hp - dmg, 0, player.maxHp);
    setPlayer(p => ({...p, hp: newHp}));
    setDefending(false);
    setShowShield(false);
    await wait(500);
    setMonsterState('idle');
    setPlayerAction('idle');
    await wait(200);
    if (newHp <= 0) await playerDefeated();
    else {
      setTurn(t => t + 1);
      setMode('command');
      setCursor(0);
    }
  };

  const monsterDefeated = async () => {
    sfx.victory();
    setMonsterState('dying');
    addLog(`${monster.name}を たおした！`, 'system');
    await wait(900);
    setMonster(m => ({...m, hp: 0}));
    await wait(300);
    addLog(`けいけんち ${monster.xp} ポイント かくとく！`, 'system');
    addLog(`${monster.gold} ゴールドを てにいれた！`, 'system');
    const newXp = player.xp + monster.xp;
    const levelUp = newXp >= player.lv * 25;
    if (levelUp) { sfx.levelUp(); addLog(`${player.name}はレベルが上がった！`, 'system'); }
    setPlayer(p => ({...p, xp: newXp, gold: p.gold + monster.gold, lv: levelUp ? p.lv+1 : p.lv}));
    await wait(700);
    setResult({ type:'victory', monster, xp: monster.xp, gold: monster.gold, levelUp });
    setMode('result');
  };

  const playerDefeated = async () => {
    sfx.defeat();
    addLog(`${player.name}は しんでしまった…`, 'dmg');
    await wait(1200);
    const lost = Math.floor(player.gold / 2);
    setResult({ type:'defeat', monster, lostGold: lost });
    setMode('result');
  };

  const handleCommand = (i) => {
    sfx.select();
    if (i === 0) playerAttack();
    else if (i === 1) { setMode('spell'); setCursor(0); }
    else if (i === 2) playerDefend();
    else if (i === 3) playerFlee();
  };
  const handleSpell = (i) => {
    if (i < 0) { sfx.cursor(); setMode('command'); setCursor(1); return; }
    sfx.select();
    playerSpell(i);
  };

  return (
    <>
      {flash && <div className="screen-flash show" style={{background: flash}}/>}
      <div className={`battle-app ${shake?'screen-shake':''}`}>
        <Field
          monster={monster} player={player}
          monsterState={monsterState}
          playerAction={playerAction}
          magicFx={magicFx}
          magicCircle={magicCircle}
          showShield={showShield}
          particles={particles}
          popups={popups}
          fieldRef={fieldRef}
        />
        <StatusStrip player={player} turn={turn}/>
        {mode !== 'result' && (
          <CommandWindow
            mode={mode} cursor={cursor}
            setCursor={(c) => { sfx.cursor(); setCursor(c); }}
            onChoose={mode === 'spell' ? handleSpell : handleCommand}
            player={player}
          />
        )}
        <LogWindow lines={log}/>
      </div>
      {result && <ResultOverlay result={result} onBack={() => location.href='board.html'}/>}
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
